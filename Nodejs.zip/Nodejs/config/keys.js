module.exports = {
    MONGO_URI: 'mongodb+srv://kunj_96:jnukdipakpatel966@nodeapiproject.ibtqm.mongodb.net/ServiceHub?retryWrites=true&w=majority'
}